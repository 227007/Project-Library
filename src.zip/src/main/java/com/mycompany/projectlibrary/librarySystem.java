/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projectlibrary;
import java.util.ArrayList;
/**
 *
 * @author BLT
 */
public class librarySystem {
    private ArrayList<Book> books;

    public librarySystem() {
        this.books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void searchByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                System.out.println("Book found: " + book.getInfo());
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void searchByAuthor(String author) {
        for (Book book : books) {
            if (book.getAuthor().equalsIgnoreCase(author)) {
                System.out.println("Book found: " + book.getInfo());
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void checkBookLoans() {
        System.out.println("Book Loans:");
        for (Book book : books) {
            if (book.inLoan()) {
                System.out.println(book.getTitle() + " by " + book.getAuthor());
            }
        }
    }
}