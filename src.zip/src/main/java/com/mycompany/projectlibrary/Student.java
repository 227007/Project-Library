/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projectlibrary;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/**
 *
 * @author BLT
 */
public class Student implements Display {
    private String id;
    private String name;
    private String address;
    private Date birthDate;
    private String major;
    private List<Book> borrowedBooks;

    public Student(String id, String name, String address, Date birthDate, String major) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.birthDate = birthDate;
        this.major = major;
        this.borrowedBooks = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public String getMajor() {
        return major;
    }

    @Override
    public String getInfo() {
        return String.format("ID: %s, Name: %s, Address: %s, Birth Date: %s, Major: %s",
                id, name, address, birthDate.toString(), major);
    }

    @Override
    public boolean inLoan() {
        return !borrowedBooks.isEmpty();
    }

    public void borrowBook(Book book) {
        if (borrowedBooks.size() < 3) {
            borrowedBooks.add(book);
            System.out.println(name + " has borrowed the book: " + book.getTitle());
        } else {
            System.out.println(name + " cannot borrow more than 3 books at a time.");
        }
    }

    public void returnBook(Book book) {
        if (borrowedBooks.contains(book)) {
            borrowedBooks.remove(book);
            System.out.println(name + " has returned the book: " + book.getTitle());
        } else {
            System.out.println(name + " did not borrow the book: " + book.getTitle());
        }
    }
}