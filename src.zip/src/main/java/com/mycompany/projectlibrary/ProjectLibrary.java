/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projectlibrary;

import java.util.Scanner;
import java.util.Date;
/**
 *
 * @author BLT
 */
public class ProjectLibrary {
     public static void main(String[] args) {
        librarySystem librarySystem = new librarySystem();
        Scanner scanner = new Scanner(System.in);

        int choice;
        do {
            displayMenu();
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    addBook(librarySystem, scanner);
                    break;
                case 2:
                    searchByTitle(librarySystem, scanner);
                    break;
                case 3:
                    searchByAuthor(librarySystem, scanner);
                    break;
                case 4:
                    checkBookLoans(librarySystem);
                    break;
                case 5:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        } while (choice != 5);

        scanner.close();
    }

    private static void displayMenu() {
        System.out.println("1. Add Book");
        System.out.println("2. Search by Title");
        System.out.println("3. Search by Author");
        System.out.println("4. Check Book Loans");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void addBook(librarySystem librarySystem, Scanner scanner) {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter author: ");
        String author = scanner.nextLine();
        System.out.print("Enter book number: ");
        int number = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Enter genre: ");
        String genre = scanner.nextLine();
        System.out.print("Enter version: ");
        String version = scanner.nextLine();
        System.out.print("Enter release date (day month year): ");
        int day = scanner.nextInt();
        int month = scanner.nextInt();
        int year = scanner.nextInt();
        java.util.Date date = new java.util.Date(day, month, year);

        Book book = new Book(title, author, number, genre, version, date);
        librarySystem.addBook(book);
        System.out.println("Book added successfully.");
    }

    private static void searchByTitle(librarySystem librarySystem, Scanner scanner) {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        librarySystem.searchByTitle(title);
    }

    private static void searchByAuthor(librarySystem librarySystem, Scanner scanner) {
        System.out.print("Enter author: ");
        String author = scanner.nextLine();
        librarySystem.searchByAuthor(author);
    }

    private static void checkBookLoans(librarySystem librarySystem) {
        librarySystem.checkBookLoans();
    }
}
